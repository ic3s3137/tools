# Fake-flash.cn

![](https://raw.githubusercontent.com/r00tSe7en/Fake-flash.cn/master/Fake-flash.cn.png)

www.flash.cn 的钓鱼页，中文+英文

在线预览：http://fake-flash.se7ensec.cn/
